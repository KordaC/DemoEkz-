package ru.exam.library;

import java.math.BigDecimal;

public class Book {
    private int id;
    private String name;
    private BigDecimal price;

    public Book(int id, String name, BigDecimal price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return id + " | " + name + " | " + price;
    }
}
