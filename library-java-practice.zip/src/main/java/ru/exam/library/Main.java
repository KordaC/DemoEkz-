package ru.exam.library;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Library Java Practice ===");
        System.out.println("Java project is working!");
        System.out.println("Next step: connect to MySQL and read books.");
    }
}
