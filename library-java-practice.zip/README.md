# Library Java Practice

Учебный проект для подготовки к демоэкзамену:
Java + MySQL + JDBC.

## Структура

- `Main.java` — точка входа.
- `DatabaseConnection.java` — подключение к MySQL.
- `Book.java` — модель книги.
- `BookRepository.java` — получение книг из БД.
- `pom.xml` — Maven и JDBC-драйвер MySQL.

## Первый этап

1. Создать MySQL БД `library`.
2. Создать таблицу `book`.
3. В `DatabaseConnection.java` указать пароль MySQL.
4. Запустить `Main`.
5. Затем изменить `Main`, чтобы он получал список книг через `BookRepository`.

## Следующие этапы подготовки

1. SELECT и вывод книг.
2. Авторизация пользователя.
3. INSERT / UPDATE / DELETE.
4. Поиск.
5. Сортировка.
6. Фильтрация.
7. Работа с заказами.
8. Простое GUI-приложение.
